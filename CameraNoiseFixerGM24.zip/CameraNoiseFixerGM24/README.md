# Camera Noise Fixer — GM24 Pro Edition

Android Kotlin starter project based on the uploaded Camera Noise Fixer HTML UI concept.

## Features
- Real CameraX front-camera preview and photo capture; front camera is selected by default.
- Automatic camera exposure/white balance/focus behavior as provided by the device camera pipeline.
- Quality-priority JPEG capture at 95% quality.
- Lightweight post-capture denoise on a working copy (max side 2560 px). If processing fails, the original saved photo remains.
- Photos saved to `Pictures/CameraNoiseFixer` in the gallery.
- Camera switching and clear error messages.
- GitHub Actions workflow builds a debug APK and uploads it as an artifact.

## Build with GitHub Actions
1. Create a new GitHub repository.
2. Upload all files in this folder to the repository root.
3. Open **Actions** and enable workflows if prompted.
4. Run **Build Camera Noise Fixer APK** with **Run workflow**, or push a commit.
5. Open the completed workflow run and download `CameraNoiseFixer-GM24-debug-apk` under **Artifacts**.
6. Extract the ZIP and install `app-debug.apk` on your phone. Allow installation from that source when Android asks.

## Notes / limitations
- This is a debug APK, not a Play Store-signed release.
- HDR, night mode, manual ISO, and DNG/RAW are not falsely advertised as active: they require additional implementation and hardware/driver support. This starter app currently uses automatic JPEG capture and gentle post-processing.
- The denoising step works on a resized copy up to 2560 px on the longest side; processed output may therefore have lower resolution than the original capture. If processing fails, the original capture is retained.
- Verify camera performance on the actual GM24 Pro. The project has not been compiled on this environment because Gradle/Android SDK are not installed here.
