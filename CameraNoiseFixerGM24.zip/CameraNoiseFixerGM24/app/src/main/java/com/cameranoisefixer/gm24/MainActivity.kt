package com.cameranoisefixer.gm24

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import java.io.OutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var statusText: TextView
    private lateinit var featureText: TextView
    private lateinit var captureButton: MaterialButton
    private lateinit var switchButton: Button
    private var imageCapture: ImageCapture? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var useFrontCamera = true
    private var isCapturing = false
    private val cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else {
            statusText.text = "Kamera izni gerekli. Ayarlardan izin verebilirsin."
            captureButton.isEnabled = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        previewView = findViewById(R.id.previewView)
        statusText = findViewById(R.id.statusText)
        featureText = findViewById(R.id.featureText)
        captureButton = findViewById(R.id.captureButton)
        switchButton = findViewById(R.id.switchButton)
        previewView.scaleType = PreviewView.ScaleType.FILL_CENTER

        captureButton.setOnClickListener { takePhoto() }
        switchButton.setOnClickListener {
            useFrontCamera = !useFrontCamera
            startCamera()
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        statusText.text = "Kamera başlatılıyor…"
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider
                val selector = if (useFrontCamera) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                if (!provider.hasCamera(selector)) {
                    statusText.text = if (useFrontCamera) "Ön kamera bulunamadı; arka kamera seçebilirsin." else "Arka kamera bulunamadı."
                    return@addListener
                }
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setJpegQuality(95)
                    .build()
                provider.unbindAll()
                provider.bindToLifecycle(this, selector, preview, imageCapture)
                statusText.text = if (useFrontCamera) "Ön kamera hazır · Otomatik kalite modu" else "Arka kamera hazır · Otomatik kalite modu"
                featureText.text = "Pozlama / beyaz dengesi: otomatik · JPEG kalite: %95\nHDR / RAW: cihaz desteğine bağlı"
                captureButton.isEnabled = true
            } catch (e: Exception) {
                statusText.text = "Kamera başlatılamadı: ${e.localizedMessage ?: "bilinmeyen hata"}"
                captureButton.isEnabled = false
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        if (isCapturing) return
        isCapturing = true
        captureButton.isEnabled = false
        statusText.text = "Fotoğraf çekiliyor ve otomatik iyileştiriliyor…"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "CameraNoiseFixer_${System.currentTimeMillis()}.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/CameraNoiseFixer")
        }
        val output = ImageCapture.OutputFileOptions.Builder(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values).build()
        capture.takePicture(output, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                val uri = result.savedUri
                if (uri == null) {
                    finishCapture("Fotoğraf kaydedildi ancak dosya konumu alınamadı.")
                    return
                }
                try {
                    applyGentleDenoise(uri)
                    finishCapture("Fotoğraf kaydedildi: Galeri › CameraNoiseFixer")
                } catch (e: Exception) {
                    finishCapture("Fotoğraf kaydedildi. İyileştirme uygulanamadı; orijinal korunuyor.")
                }
            }
            override fun onError(exception: ImageCaptureException) {
                finishCapture("Çekim hatası: ${exception.message ?: "bilinmeyen hata"}")
            }
        })
    }

    // Lightweight post-processing on a resized working copy to avoid exhausting memory on phones.
    // Original capture remains untouched if processing fails.
    private fun applyGentleDenoise(uri: Uri) {
        val source = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return
        val maxSide = 2560
        val scale = min(1f, maxSide.toFloat() / max(source.width, source.height).toFloat())
        val working = if (scale < 1f) Bitmap.createScaledBitmap(source, (source.width * scale).toInt().coerceAtLeast(1), (source.height * scale).toInt().coerceAtLeast(1), true) else source
        if (working !== source) source.recycle()
        val w = working.width; val h = working.height
        val input = IntArray(w * h)
        working.getPixels(input, 0, w, 0, 0, w, h)
        val output = IntArray(input.size)
        for (y in 0 until h) {
            val ym = max(0, y - 1); val yp = min(h - 1, y + 1)
            for (x in 0 until w) {
                val xm = max(0, x - 1); val xp = min(w - 1, x + 1)
                val c = input[y * w + x]
                val n = input[y * w + xm]; val e = input[y * w + xp]
                val s = input[ym * w + x]; val d = input[yp * w + x]
                fun channel(shift: Int): Int {
                    val center = (c shr shift) and 255
                    val avg = (((n shr shift) and 255) + ((e shr shift) and 255) + ((s shr shift) and 255) + ((d shr shift) and 255)) / 4
                    // Blend only 12% toward neighbours to reduce fine grain while retaining detail.
                    return (center * 0.88f + avg * 0.12f).toInt().coerceIn(0, 255)
                }
                output[y * w + x] = Color.argb(Color.alpha(c), channel(16), channel(8), channel(0))
            }
        }
        val enhanced = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        enhanced.setPixels(output, 0, w, 0, 0, w, h)
        val stream: OutputStream? = contentResolver.openOutputStream(uri, "wt")
        stream?.use { enhanced.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        enhanced.recycle(); working.recycle()
    }

    private fun finishCapture(message: String) {
        runOnUiThread {
            isCapturing = false
            captureButton.isEnabled = true
            statusText.text = message
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}
